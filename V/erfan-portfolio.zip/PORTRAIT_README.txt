Place your portrait photo here:
assets/images/erfan-moghadam.jpg

Recommended: vertical portrait, simple background, at least ~1000 px tall.
