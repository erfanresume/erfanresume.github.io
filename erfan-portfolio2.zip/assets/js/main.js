(() => {
  const root = document.documentElement;
  const header = document.getElementById("siteHeader");
  const themeToggle = document.getElementById("themeToggle");
  const menuToggle = document.getElementById("menuToggle");
  const mobileMenu = document.getElementById("mobileMenu");
  const progress = document.querySelector(".page-progress span");
  const cursorGlow = document.querySelector(".cursor-glow");

  const savedTheme = localStorage.getItem("erfan-theme-v4");
  root.dataset.theme = savedTheme || "light";

  themeToggle?.addEventListener("click", () => {
    const next = root.dataset.theme === "dark" ? "light" : "dark";
    root.dataset.theme = next;
    localStorage.setItem("erfan-theme-v4", next);
    window.dispatchEvent(new CustomEvent("themechange", { detail: next }));
  });

  function setMenu(open) {
    menuToggle?.classList.toggle("open", open);
    mobileMenu?.classList.toggle("open", open);
    mobileMenu?.setAttribute("aria-hidden", String(!open));
  }

  menuToggle?.addEventListener("click", () => {
    setMenu(!mobileMenu.classList.contains("open"));
  });

  mobileMenu?.querySelectorAll("a").forEach(a => {
    a.addEventListener("click", () => setMenu(false));
  });

  function onScroll() {
    const y = window.scrollY;
    header?.classList.toggle("scrolled", y > 24);

    const max = document.documentElement.scrollHeight - window.innerHeight;
    if (progress) progress.style.width = `${max > 0 ? (y / max) * 100 : 0}%`;
  }

  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  if (window.matchMedia("(pointer: fine)").matches && cursorGlow) {
    let raf = 0;
    window.addEventListener("pointermove", e => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        cursorGlow.style.left = `${e.clientX}px`;
        cursorGlow.style.top = `${e.clientY}px`;
        raf = 0;
      });
    }, { passive: true });
  }

  // Lightweight 3D tilt — no GSAP required.
  const tiltTargets = [
    [document.getElementById("portraitTilt"), document.getElementById("portraitCard")],
    ...[...document.querySelectorAll(".tilt-card")].map(el => [el, el])
  ];

  if (window.matchMedia("(pointer: fine)").matches) {
    tiltTargets.forEach(([area, target]) => {
      if (!area || !target) return;

      area.addEventListener("pointermove", e => {
        const r = area.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width;
        const py = (e.clientY - r.top) / r.height;

        target.style.transform =
          `perspective(1100px) rotateX(${-(py - .5) * 5}deg) rotateY(${(px - .5) * 6}deg) translateY(-2px)`;

        target.style.setProperty("--mx", `${px * 100}%`);
        target.style.setProperty("--my", `${py * 100}%`);
      });

      area.addEventListener("pointerleave", () => {
        target.style.transform = "";
      });
    });
  }

  // Native reveal observer: lighter than a full animation library.
  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: .12, rootMargin: "0px 0px -6% 0px" });

  document.querySelectorAll(".reveal").forEach(el => revealObserver.observe(el));

  // Active navigation.
  const sections = [...document.querySelectorAll("main section[id]")];
  const navLinks = [...document.querySelectorAll(".desktop-nav a")];

  const sectionObserver = new IntersectionObserver(entries => {
    const visible = entries
      .filter(e => e.isIntersecting)
      .sort((a,b) => b.intersectionRatio - a.intersectionRatio)[0];

    if (!visible) return;

    navLinks.forEach(a => {
      a.classList.toggle(
        "active",
        a.getAttribute("href") === `#${visible.target.id}`
      );
    });
  }, { threshold: [0.18, .35], rootMargin: "-10% 0px -45% 0px" });

  sections.forEach(s => sectionObserver.observe(s));
})();
